//
//  ClusterCollectionViewCell.swift
//  NewCollectionXib
//
//  Created by ikom on 23/03/22.
//

import UIKit

class ClusterCollectionViewCell: UICollectionViewCell {
    
    //MARK:- IBOUTLETS
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var lblSubjectName: UILabel!
    @IBOutlet weak var clusterRatingView: UIView!
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var lblDaysLeft: UILabel!
    @IBOutlet weak var downloadView: UIView!
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var imgStatus: UIImageView!
    @IBOutlet weak var lblDownloadedStatus: UILabel!
    @IBOutlet weak var imgDownloaded: UIImageView!
    @IBOutlet weak var imgSubject: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        mainView.layer.borderColor = UIColor.lightGray.cgColor
        mainView.layer.borderWidth = 1.0
        mainView.layer.cornerRadius = 8.0
    }
    
}
