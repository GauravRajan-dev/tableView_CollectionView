//
//  ViewController.swift
//  NewCollectionXib
//
//  Created by ikom on 23/03/22.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- IBOutlets
    @IBOutlet weak var tblVwCluster: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

//MARK:- DataSource And Delegates
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClusterTableViewCell", for: indexPath) as! ClusterTableViewCell
        print("indexPath.section, \(indexPath.section + 2)")
        cell.arrCount = indexPath.section + 2
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UIDevice.current.userInterfaceIdiom == .pad ? 500 : 280
    }
}
