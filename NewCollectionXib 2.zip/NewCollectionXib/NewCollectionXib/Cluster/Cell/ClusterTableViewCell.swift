//
//  ClusterTableViewCell.swift
//  NewCollectionXib
//
//  Created by ikom on 23/03/22.
//

import UIKit

class ClusterTableViewCell: UITableViewCell {
    
    //MARK:- Outlets
    @IBOutlet weak var pageCtrl: UIPageControl!
    @IBOutlet weak var clcVwCluster: UICollectionView!
    
    //MARK:- Var decalarations
    fileprivate var currentPage: Int = 0
    
    var arrCount = 0
    
    //MARK:- TableViewCell Method
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.clcVwCluster.register(UINib.init(nibName: "ClusterCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ClusterCollectionViewCell")
        
        clcVwCluster.delegate = self
        clcVwCluster.dataSource = self
        
        self.clcVwCluster.layer.cornerRadius = 2.0
        self.clcVwCluster.layer.borderWidth = 1.0
        self.clcVwCluster.layer.borderColor = UIColor.gray.cgColor
        //  self.pageCtrl.layer.borderWidth = 1.0
        //  self.pageCtrl.layer.borderColor = UIColor.lightGray.cgColor
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

extension ClusterTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        pageCtrl.currentPage = 0
        print("arrCount, \(arrCount)")
        
        if arrCount % 2 == 0 {
            print("Number is even")
            pageCtrl.numberOfPages = arrCount/2
        } else {
            print("Number is odd")
            if  arrCount > 1 {
                pageCtrl.numberOfPages = (arrCount/2) + 1
            } else {
                pageCtrl.numberOfPages = (arrCount/2)
            }
        }

     
        
        
        
        return arrCount
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "ClusterCollectionViewCell", for: indexPath) as! ClusterCollectionViewCell
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        //let padding : CGFloat = 40.0
        if UIDevice.current.userInterfaceIdiom == .pad {
            let cellSize = (collectionView.frame.size.width / 2) - 40
            return CGSize.init(width: cellSize, height: cellSize + 50)
        }
        
        let cellSize = (collectionView.frame.size.width - 10)/2
        return CGSize.init(width: cellSize, height: cellSize + 40)
        
    }
    
    
    
    //MARK:- Scroll view events for handling page control
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageSide = self.clcVwCluster.frame.width
        let offset = scrollView.contentOffset.x
        currentPage = Int(floor((offset - pageSide / 2) / pageSide) + 1)
        pageCtrl.currentPage = currentPage
        print("currentPage " + currentPage.description)
    }
}
